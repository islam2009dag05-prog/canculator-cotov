﻿

Console.WriteLine("      |\\      _,,,---,,_\r\nZZZzz /,`.-'`'    -.  ;-;;,_\r\n     |,4-  ) )-,_. ,\\ (  `'-'\r\n    '---''(_/--'  `-'\\_)");
Console.WriteLine("\nНажми на кнопку чтобы продолжить:");
Console.ReadKey();

Console.WriteLine("\nПривет Ксень!\t Этот Конкулятор Создан лично для тебя! ");
Console.WriteLine("Введи первое число:\r\n");

int num1 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Введи второе число: \r\n");
int num2  = Convert.ToInt32(Console.ReadLine());
Console.WriteLine(" Введи  символ (+, -, *, /): \r \n");
 
char simvol = Convert.ToChar(Console.ReadLine());
    double resultat = 0;

if (simvol == '+')
{
    resultat = num1 + num2;
    Console.WriteLine("Результат  сложения: " + resultat);
}
if (simvol == '-')
{
    resultat = num1 - num2;
    Console.WriteLine("Результат вычитания: " + resultat);
}
       if (simvol == '*') { 

    resultat = num1 * num2;
    Console.WriteLine("Результат умножения:" + resultat);
}
if (simvol == '/')
{
    if (num2 == 0)

        Console.WriteLine("Ответ получается 0.");

    resultat = num1 / num2;
    Console.WriteLine("Результат деления:" + resultat);
}


Console.WriteLine("\n _._     _,-'\"\"`-._\r\n(,-.`._,'(       |\\`-/|\r\n    `-.-' \\ )-`( , o o)\r\n          `-    \\`_`\"'-");